#!/usr/bin/env python3
"""Install the exact user-supplied Claude sprite sheets into a local game repo.

Usage:
  python install_claude_sprites.py /path/to/olive-amber-juniper-fjord

The extracted public/ folder must be next to this installer. Does not modify
Grok/Claude branches remotely; run in a locally checked-out feature branch.
"""
from pathlib import Path
from shutil import copy2
import re, sys, subprocess

pack=Path(__file__).resolve().parent
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
registry=repo/'src/game-v2/assets/characters.ts'
if not registry.exists(): raise SystemExit(f'Game repository not found: {repo}')
if not (pack/'public/game-v2/characters/pedestrians/orange_woman/front.png').exists():
 raise SystemExit('Extract this installer along with the complete sprite pack.')

peds={
'male01':('green_jacket_man',1.78), 'female01':('orange_woman',1.72),
'male02':('blue_hoodie_boy',1.62),'female02':('denim_girl',1.68),
'male03':('black_hoodie_man',1.79),'female03':('pink_jacket_girl',1.64),
'male04':('bucket_hat_oldman',1.71),'female04':('purple_tracksuit_kid',1.55),
}
# Carry over all built/legacy files except where a corresponding new canonical
# file exists. This preserves audio, missions, UI, and the old Benji walk art.
count=0
for src in (pack/'public').rglob('*.png'):
 dest=repo/'public'/src.relative_to(pack/'public')
 dest.parent.mkdir(parents=True,exist_ok=True)
 copy2(src,dest)
 count+=1

# Adapt cast source names to the runtime contract, including retaining the
# original character-specific width/height from current registry.
text=registry.read_text()
cast_old={
 'benji':'benji','kBlanco':'k-blanco','courtOg':'court-og',
 'mamaDee':'mama-dee','uncJ':'unc-j','nitro':'nitro','strike':'strike',
}
# Core cast paths already match the four directional names in the atlas ZIP,
# so no changes to the direct named turnaround() registries are necessary.
# Pedestrian names remain the same runtime keys, now pointing to 8 actual
# Claude/Higgsfield characters with all directions + walk.
start=text.index('  pedestrian: {')
end=text.index('\n  },\n} as const satisfies',start)+len('\n  },')
new='  pedestrian: {\n'
for key,(name,height) in peds.items():
 new+=(f'    {key}: {{ id: "ped-{name.replace("_", "-")}", height: {height}, '
       f'views: {{ ...turnaround("pedestrians/{name}"), '
       f'walk: cut("/game-v2/characters/pedestrians/{name}/walk.png") }} }},\n')
new+='  },'
text=text[:start]+new+text[end:]
text=text.replace('Named cast is cut from the Character Bible photographs\n * (SackReligious_Character_Bible_AI_Reference_Pack). Not the old\n * illustrated public/game people.',
                  'Named cast and eight pedestrians come from the user-approved\n * Claude illustrated atlases. No photo-human replacements.')
text=text.replace(' * Walk art is PARTIAL. Front has standing + one stride frame.',
                  ' * Pedestrian walk art contains one additional illustrated step frame.')
text=text.replace(' * Back, left, and right are standing frames only. Those views\n * translate. They do not bob, hop, or scale.',
                  ' * All pedestrians have front/back/left/right. Cast directional art\n * is canonical; avoid any unsupported bobbing or size popping.')
text=text.replace('const cut = (src: string): Cutout => {','const cut = (src: string): Cutout => {')
text=text.replace('return { src: `${src}?v=10`, footPad:', 'return { src: `${src}?v=11`, footPad:')
registry.write_text(text)

# Rename the delivered vehicle views according to the CURRENT code's
# `kind-face` file contract. Assets remain independent illustrated views.
vehicle_dir=repo/'public/game-v2/vehicles'
for kind in ('coupe','sedan','suv','van'):
 for old_face,new_face in {'side':'left','side-reverse':'right','front':'front','rear':'back'}.items():
  source=pack/'public/game-v2/vehicles'/f'{kind}-{old_face}.png'
  assert source.exists(),source
  dest=vehicle_dir/f'{kind}-{new_face}.png'
  copy2(source,dest)
  count+=1

analysis=repo/'scripts/analyze-character-alpha.py'
if not analysis.exists():raise SystemExit('Missing alpha-bound analyzer; installation incomplete')
subprocess.check_call([sys.executable,str(analysis)],cwd=repo)
# Require exact eight illustrated identities; runtime can never silently fall
# back to male-01 / female-01 or old photo-style NPC placeholders.
assert 'pedestrians/green_jacket_man' in registry.read_text()
assert 'pedestrians/orange_woman' in registry.read_text()
print(f'Copied {count} canonical sprites and updated character registry + alpha bounds')
print('Now run npm run typecheck, npm run lint, npm run build, and browser QA.')
