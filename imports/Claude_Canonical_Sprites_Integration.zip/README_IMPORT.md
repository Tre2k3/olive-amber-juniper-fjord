# Claude sprite replacement integration pack

This is sourced from the TWO PNG sheets uploaded in this conversation, not from generated replacement characters. Crops are determined by transparent row/column gaps and checked visually. 40 pedestrian frames, 29 core cast frames, 16 vehicle frames. Each person uses a stable canvas per identity and keeps the shoe sole as the measured ground anchor.

Important: The CURRENT GitHub production branch still points `src/game-v2/assets/characters.ts` at its earlier Character Bible crop set and uses `male-01.png` / `female-01.png` front-only generic pedestrians. Until source code is switched AND these extracted PNGs are added to GitHub, GitHub gameplay will keep showing the older art.

### Installation in a checked-out clone

1. Copy the `public/game-v2/characters/` and `public/game-v2/vehicles/` directories from this package into the repo; do not delete existing files yet.
2. Register all eight named pedestrians with the new `front/back/left/right/walk` paths, instead of current `male-01/female-01` generic source filenames.
3. Point the canonical cast to each matching `front/back/left/right`. Keep the old Benji walk animation unless you have a true motion frame; `front_alt` is not a walk animation.
4. Merge the generated `claude-character-bounds.ts` entries into the alpha lookup or re-run `python scripts/analyze-character-alpha.py` in the repo to recompute all sprite bounds.
5. Match the vehicle sprite filename contract (original runtime currently expects `coupe-left.png` etc) to the extracted side/front/rear files. Vehicle left and right can come from independently exported side sprites.
6. Run `npm run typecheck`, `npm run lint`, `npm run build`, `npm run test:foundation` and visual screenshots at day/night.
7. Never silently switch to photo humans or fallback to different character identities if an asset cannot load.

This package does **not** mean the live GitHub branch has the assets. PNG artwork requires a binary GitHub upload/commit step. The GitHub text-file connector cannot put binary PNG files directly into the repo. Existing game still unchanged unless that asset commit happens.
